let idx=0;
let questions=[];
fetch('questions.json').then(r=>r.json()).then(d=>{
  questions=d;
  show();
});
function show(){
  const q=questions[idx];
  document.getElementById('quiz').innerHTML=
    '<p>'+q.q+'</p>' +
    q.options.map((o,i)=>'<label><input type=radio name=opt value='+i+'>'+o+'</label><br>').join('');
}
function nextQuestion(){
  idx=(idx+1)%questions.length;
  show();
}
